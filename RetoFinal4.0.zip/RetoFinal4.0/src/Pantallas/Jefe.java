package Pantallas;

import javax.swing.JPanel;

import Clases.Empleado;

public class Jefe extends JPanel {

	/**
	 * Create the panel.
	 */
	public Jefe(Empleado user) {

	}

}
