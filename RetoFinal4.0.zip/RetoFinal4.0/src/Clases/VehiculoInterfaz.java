package Clases;

public interface VehiculoInterfaz {
	boolean anadirVehiculo(Vehiculo vehiculo);
	boolean estaReparado(Vehiculo vehiculo);
	boolean estaVendido(Vehiculo vehiculo);	
}
