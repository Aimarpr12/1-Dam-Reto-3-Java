package Clases;

public interface EmpleadoInterfaz {
	boolean addEmpleado(Empleado user); 
	boolean deleteEmpleado(Empleado user);
}
