package Clases;

public enum Motor {
	Gasolina,
	Diesel,
	Electrico
	
}
