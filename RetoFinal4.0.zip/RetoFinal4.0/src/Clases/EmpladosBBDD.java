package Clases;

public interface EmpladosBBDD {
	boolean anadirEmpleado(Empleado empleado);
	boolean editarEmpleado(Empleado empleado);
	boolean eliminarEmpleado(Empleado empleado);
}
