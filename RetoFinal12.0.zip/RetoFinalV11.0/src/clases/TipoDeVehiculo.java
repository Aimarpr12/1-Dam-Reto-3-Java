package clases;

public enum TipoDeVehiculo {
	coche,
	moto
}
