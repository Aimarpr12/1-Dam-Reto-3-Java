package clases;

public enum Motor {
	Gasolina,
	Diesel,
	Electrico
	
}
