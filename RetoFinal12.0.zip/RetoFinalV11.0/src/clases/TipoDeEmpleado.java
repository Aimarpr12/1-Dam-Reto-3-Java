package clases;

public enum TipoDeEmpleado {
	jefe,
	vendedor,
	mecanico
}
