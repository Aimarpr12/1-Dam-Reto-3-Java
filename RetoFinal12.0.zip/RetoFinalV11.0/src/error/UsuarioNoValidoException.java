package error;

public class UsuarioNoValidoException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UsuarioNoValidoException(String mensaje) {
        super(mensaje);
    }
}
