package pantallas;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import clases.Empleado;
import controller.Controller;

import java.awt.Color;
import java.awt.SystemColor;
import java.awt.Font;

public class PantallaInicioJefe extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Create the panel.
	 */
	private Controller controller;
	private List <Empleado> listaDeEmpleados;
	private JTable table;
	private DefaultTableModel model;
	private JComboBox comboBoxEmpleo;
	private JComboBox comboBoxElementoAModificar;
	private boolean primeraVez = true;
	public PantallaInicioJefe(Empleado user, Controller controller2) {
		setBackground(new Color(255, 252, 244));
		setLayout(null);
		this.controller = controller2;

		labelNombre(user);

		filtrarDatosTabla(user);

		ponerTodosLosUsersALaLista(); 


		btnVerVentas(user);

		btnVerReparaciones(user);

		buttonLogOut();
	}

	private void buttonLogOut() {
		JButton btnLogOut = new JButton("LogOut");
		btnLogOut.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnLogOut.setForeground(new Color(255, 255, 255));
		btnLogOut.setBackground(SystemColor.textHighlight);
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Component component = (Component) e.getSource();
				App app = (App) SwingUtilities.getRoot(component);
				app.logIn();
			}
		});
		btnLogOut.setBounds(706, 97, 89, 23);
		add(btnLogOut);		
	}

	private void btnVerReparaciones(Empleado user) {
		JButton btnVerTodasLasReparaciones = new JButton("Ver Reparaciones");
		btnVerTodasLasReparaciones.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnVerTodasLasReparaciones.setForeground(new Color(255, 255, 255));
		btnVerTodasLasReparaciones.setBackground(SystemColor.textHighlight);
		btnVerTodasLasReparaciones.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Component component = (Component) e.getSource();
				App app = (App) SwingUtilities.getRoot(component);
				app.mostrarVerReparaciones(user);
			}
		});
		btnVerTodasLasReparaciones.setBounds(629, 298, 163, 23);
		add(btnVerTodasLasReparaciones);
	}

	private void btnVerVentas(Empleado user) {
		JButton btnVerTodasLasVentas = new JButton("Ver Ventas");
		btnVerTodasLasVentas.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnVerTodasLasVentas.setForeground(new Color(255, 255, 255));
		btnVerTodasLasVentas.setBackground(SystemColor.textHighlight);
		btnVerTodasLasVentas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Component component = (Component) e.getSource();
				App app = (App) SwingUtilities.getRoot(component);
				app.mostrarVerVentas(user);
			}
		});
		btnVerTodasLasVentas.setBounds(629, 343, 163, 23);
		add(btnVerTodasLasVentas);

	}


	private void ponerTodosLosUsersALaLista() {
		if (primeraVez) {
			primeraVez = false;
			controller.cargarListaDeEmpleados();
			controller.cargarListaDeReparaciones();
			controller.cargarListaDeVentas(); 
			controller.cargarListaDeClientes();
			controller.cargarListaDeVehiculos();
			controller.cargarListaDeClienteVehiculos();

			listaDeEmpleados =  controller.getAllEmpleado();
			mostrarTablaDeUsers();
		}
	}

	private void mostrarTablaDeUsers() {		

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(62, 250, 546, 190);
		add(scrollPane);

		table = new JTable();
		table.setDefaultEditor(Object.class, null);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		model = new DefaultTableModel();
		table.setModel(model);

		model.addColumn("DNI");
		model.addColumn("Nombre");
		model.addColumn("Apellido");
		model.addColumn("Salario");

		añadirempleadosALaLista();

		scrollPane.setViewportView(table);
		table.setVisible(true);	
	}

	private void añadirempleadosALaLista() {
		for (Empleado empleado : listaDeEmpleados) {
			Object[] fila = new Object [4];
			fila[0]= empleado.getDni();
			fila[1]= empleado.getNombre();
			fila[2]= empleado.getApellido();
			fila[3] = empleado.getSalario();

			model.addRow(fila); 
		}
	}

	private void filtrarDatosTabla(Empleado user) {
		filtrarPorTipoDeEpleado(user);
		filtrarPorSueldo();
		buttonAplicar(user);

	}

	private void buttonAplicar(Empleado user) {
		JButton btnAplicar = new JButton("Aplicar");
		btnAplicar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAplicar.setForeground(new Color(255, 255, 255));
		btnAplicar.setBackground(SystemColor.textHighlight);
		btnAplicar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 

				String empleoSelecciona = (String) comboBoxEmpleo.getSelectedItem();
				if (table != null) {
					model.setNumRows(0); 
				}
				if (empleoSelecciona == "vendedor") {
					listaDeEmpleados = user.getAllEmpeladosVendedor(controller);
					añadirempleadosALaLista();
				}else if(empleoSelecciona == "mecanico"){
					listaDeEmpleados = user.getAllEmpeladosMecanico(controller);
					añadirempleadosALaLista();
				}else {
					listaDeEmpleados =  controller.getAllEmpleado();
					añadirempleadosALaLista();
				}
			}
		});
		btnAplicar.setBounds(379, 203, 89, 23);
		add(btnAplicar);
	}

	private void filtrarPorSueldo() {
		labelSueldo();
	}

	private void labelSueldo() {
	}

	private void filtrarPorTipoDeEpleado(Empleado user) {
		labelDepartamento();
		JComboboxEmpleo();
	}

	private void JComboboxEmpleo() {
		comboBoxEmpleo = new JComboBox<>();
		comboBoxEmpleo.setBackground(new Color(255, 255, 255));
		comboBoxEmpleo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		comboBoxEmpleo.setBounds(62, 203, 307, 22);
		comboBoxEmpleo.addItem("seleciona un empleo");
		comboBoxEmpleo.addItem("vendedor");
		comboBoxEmpleo.addItem("mecanico");
		add(comboBoxEmpleo);
	}

	private void labelDepartamento() {		
		JLabel labelDepartameto = new JLabel("Departamento");
		labelDepartameto.setFont(new Font("Tahoma", Font.PLAIN, 15));
		labelDepartameto.setForeground(new Color(255, 128, 0));
		labelDepartameto.setBounds(62, 178, 130, 14);
		add(labelDepartameto);

	}

	private void labelNombre(Empleado user) {
		JLabel labelNombre = new JLabel(user.getNombre());
		labelNombre.setFont(new Font("Tahoma", Font.BOLD, 15));
		labelNombre.setForeground(new Color(255, 128, 0));
		labelNombre.setBounds(494, 101, 176, 14);
		add(labelNombre);
	}
}

